<template>
  <div id="app" class="container">

    <div class="row">
      <div class="col-md-4 col-xs-12 tab">
        
        <div class="form-group row">
          <div class="col-lg-12">
            <select class="form-control gross-or-net" v-model="TypeSearch">
              <option value="GROSS sang NET">GROSS sang NET</option>
              <option value="NET sang GROSS">NET sang GROSS</option>
            </select>
          </div>
        </div>

        <div class="form-group row">
          <div class="col-md-6 col-xs-12">
            Chọn đơn vị tiền
            <select class="form-control gross-or-net" v-model="LoaiNT">
              <option value="VNĐ">VNĐ</option>
              <option value="USD">USD</option>
              <option value="EUR">EUR</option>
              <option value="GBP">GBP</option>
              <option value="CAD">CAD</option>
              <option value="HKD">HKD</option>
              <option value="FRF">FRF</option>
              <option value="CHF">CHF</option>
              <option value="JPY">JPY</option>
              <option value="AUD">AUD</option>
              <option value="SGD">SGD</option>
              <option value="Other">Ngoại tệ khác</option>
            </select>
          </div>
          <div v-if="LoaiNT == 'VNĐ'" class="col-md-6 col-xs-12">
            Tiền thu nhập
            <input class="form-control" type="number" step="1000000" v-model="SalarySearch" placeholder="Thu nhập" />
          </div>
        </div>

        <div v-if="LoaiNT != 'VNĐ'" class="form-group row">
          <div class="col-md-6 col-xs-12">
            Lương ngoại tệ
            <input class="form-control" type="number" step="10" v-model="SalaryNgoaiTe" placeholder="Lương ngoại tệ" />
          </div>
          <div class="col-md-6 col-xs-12">
            Tỉ giá
            <input class="form-control" type="number" v-model="TiGia" placeholder="Tỉ giá" />
          </div>
        </div>

        <div class="form-group row">
          <div class="col-md-6 col-xs-12">
            Lương đóng bảo hiểm
            <input class="form-control" type="number" step="1000000" v-model="SalaryDongBHSearch" placeholder="Lương đóng BH" />
          </div>
          <div class="col-md-6 col-xs-12">
            Số người phụ thuộc
            <input class="form-control" type="number" v-model="SoLuongNPT" placeholder="Số người phụ thuộc">
          </div>
        </div>

        <div class="form-group row">
          <div class="col-md-12" style="text-align: right; margin-top: 15px">
            <i>**Áp dụng từ 1/1/2019</i>
          </div>
        </div>

        <div class="form-group row img-place">
          <div class="col-md-12 hidden-sm" style="padding: 15px 25%;">
            <img src="https://intertax.vn/wp-content/uploads/2019/07/calculation.png" width="100%">
          </div>
        </div>
        
      </div>

      <div class="col-md-4 col-xs-12 tab">

        {{funcTinhLuong}}

        <div v-if="TypeSearch == 'GROSS sang NET'">

          <table class="table table-hover">
            <thead>
              <tr>
                <th colspan="2">QUY ĐỔI GROSS SANG NET</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Lương GROSS</td>
                <td>{{salaryCalculated | toCurrency}}</td>
                <input type="hidden" v-model="salaryCalculated" />
              </tr>
              <tr>
                <td>BHXH (8%)</td>
                <td>{{feeBHXH | toCurrency}}</td>
                <input type="hidden" v-model="feeBHXH" />
              </tr>
              <tr>
                <td>BHYT (1.5%)</td>
                <td>{{feeBHYT | toCurrency}}</td>
                <input type="hidden" v-model="feeBHYT" />
              </tr>
              <tr>
                <td>BHTN (1%)</td>
                <td>{{feeBHTN | toCurrency}}</td>
                <input type="hidden" v-model="feeBHTN" />
              </tr>
              <tr style="background: rgba(241, 111, 48, 0.25);">
                <td>Thu nhập trước thuế</td>
                <td>{{thuNhapTruocThue | toCurrency}}</td>
              </tr>
              <tr>
                <td>Giảm trừ bản thân</td>
                <td>{{giamTruBT | toCurrency}}</td>
              </tr>
              <tr>
                <td>Giảm trử gia cảnh NPT</td>
                <td>{{giamTruNPT | toCurrency}}</td>
              </tr>
              <tr style="background: rgba(241, 111, 48, 0.3);">
                <td>Thu nhập chịu thuế</td>
                <td>{{thuNhapChiuThue | toCurrency}}</td>
              </tr>
              <tr>
                <td><b>Thuế TNCN</b></td>
                <td><b>{{thueTNCN | toCurrency}}</b></td>
              </tr>
              <tr>
                <td><b>Lương NET</b></td>
                <td><b>{{luongNet | toCurrency}}</b></td>
              </tr>
            </tbody>
          </table>

        </div>
          
        <div v-if="TypeSearch == 'NET sang GROSS'">

          <table class="table table-hover">
            <thead>
              <tr>
                <th colspan="2">QUY ĐỔI NET SANG GROSS</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Lương NET</td>
                <td>{{salaryCalculated | toCurrency}}</td>
                <input type="hidden" v-model="salaryCalculated" />
              </tr>
              <tr>
                <td>BHXH (8%)</td>
                <td>{{feeBHXH | toCurrency}}</td>
                <input type="hidden" v-model="feeBHXH" />
              </tr>
              <tr>
                <td>BHYT (1.5%)</td>
                <td>{{feeBHYT | toCurrency}}</td>
                <input type="hidden" v-model="feeBHYT" />
              </tr>
              <tr>
                <td>BHTN (1%)</td>
                <td>{{feeBHTN | toCurrency}}</td>
                <input type="hidden" v-model="feeBHTN" />
              </tr>
              <tr>
                <td>Thu nhập tính thuế NET</td>
                <td>{{thuNhapTinhThueNet | toCurrency}}</td>
              </tr>
              <tr>
                <td>Giảm trừ bản thân</td>
                <td>{{giamTruBT | toCurrency}}</td>
              </tr>
              <tr>
                <td>Giảm trử gia cảnh NPT</td>
                <td>{{giamTruNPT | toCurrency}}</td>
              </tr>
              <tr>
                <td>Thu nhập chịu thuế</td>
                <td>{{thuNhapChiuThue | toCurrency}}</td>
              </tr>
              <tr>
                <td><b>Thuế TNCN</b></td>
                <td><b>{{thueTNCN | toCurrency}}</b></td>
              </tr>
              <tr>
                <td>Quy đổi sang Gross</td>
                <td>{{quyDoiSangGross | toCurrency}}</td>
              </tr>
              <tr>
                <td><b>Lương GROSS</b></td>
                <td><b>{{luongGross | toCurrency}}</b></td>
              </tr>
            </tbody>
          </table>
          
        </div>

        
      </div>

      <div class="col-md-4 col-xs-12 tab">
          
        <table class="table table-hover">
          <thead>
            <tr>
              <th colspan="2">CÁC KHOẢN CÔNG TY PHẢI TRẢ</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Lương GROSS</td>
              <td>{{luongGross | toCurrency}}</td>
              <input type="hidden" v-model="luongGross" />
            </tr>
            <tr>
              <td>BHXH (17.5%)</td>
              <td>{{feeBHXH_CT | toCurrency}}</td>
              <input type="hidden" v-model="feeBHXH_CT" />
            </tr>
            <tr>
              <td>BHYT (3%)</td>
              <td>{{feeBHYT_CT | toCurrency}}</td>
              <input type="hidden" v-model="feeBHYT_CT" />
            </tr>
            <tr>
              <td>BHTN (1%)</td>
              <td>{{feeBHTN_CT | toCurrency}}</td>
              <input type="hidden" v-model="feeBHTN_CT" />
            </tr>
            <tr>
              <td><b>Tổng cộng</b></td>
              <td><b>{{sumSalary_CT | toCurrency}}</b></td>
            </tr>
          </tbody>
        </table>

        <table class="table table-hover">
          <thead>
            <tr>
              <th colspan="2">CHI TIẾT THUẾ THU NHẬP CÁ NHÂN</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>THUẾ SUẤT</td>
              <td>VNĐ</td>
            </tr>
            <tr>
              <td>5% - Đến 5 Triệu</td>
              <td>{{thueTNCN_5 | toCurrency}}</td>
            </tr>
            <tr>
              <td>10% - Trên 5 Triệu đến 10 Triệu</td>
              <td>{{thueTNCN_10 | toCurrency}}</td>
            </tr>
            <tr>
              <td>15% - Trên 10 Triệu đến 18 Triệu</td>
              <td>{{thueTNCN_18 | toCurrency}}</td>
            </tr>
            <tr>
              <td>20% - Trên 18 Triệu đến 32 Triệu</td>
              <td>{{thueTNCN_32 | toCurrency}}</td>
            </tr>
            <tr>
              <td>25% - Trên 32 Triệu đến 52 Triệu</td>
              <td>{{thueTNCN_52 | toCurrency}}</td>
            </tr>
            <tr>
              <td>30% - Trên 52 Triệu đến 80 Triệu</td>
              <td>{{thueTNCN_80 | toCurrency}}</td>
            </tr>
            <tr>
              <td>35% - Trên 80 Triệu</td>
              <td>{{thueTNCN_80_ | toCurrency}}</td>
            </tr>
            <tr>
              <td><b>Personal Income Tax</b></td>
              <td><b>{{thueTNCN | toCurrency}}</b></td>
            </tr>
          </tbody>
        </table>
        
      </div>
    </div>
    

  </div>
</template>

<script>
import Vue from 'vue'
Vue.filter('toCurrency', function (value) {
  // let val = (value/1).toFixed(2).replace('.', ',')
  let val = value || 0
  return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
});

export default {
  name: "app",
  data() {
    return {
      PERCENT_BHXH_NV: 0.08,
      PERCENT_BHYT_NV: 0.015,
      PERCENT_BHTN_NV: 0.01,
      PERCENT_BHXH_CT: 0.175,
      PERCENT_BHYT_CT: 0.03,
      PERCENT_BHTN_CT: 0.01,
      GIAM_BT_NV: 9000000,
      GIAM_NPT_NV: 3600000,

      TypeSearch: "GROSS sang NET",

      SalarySearch: "",

      LoaiNT: "VNĐ",
      SalaryNgoaiTe: "",
      TiGia: "",

      SalaryDongBHSearch: "",
      
      SoLuongNPT: 0,

      // ==========================================

      salaryCalculated: 0,

      feeBHXH: 0,
      feeBHYT: 0,
      feeBHTN: 0,

      thuNhapTruocThue: 0,
      thuNhapChiuThue: 0,

      giamTruBT: 0,
      giamTruNPT: 0,

      thueTNCN: 0,
      
      luongGross: 0,
      luongNet: 0,

      thuNhapTinhThueNet: 0,
      quyDoiSangGross: 0,

      feeBHXH_CT: 0,
      feeBHYT_CT: 0,
      feeBHTN_CT: 0,

      thueTNCN_5: 0,
      thueTNCN_10: 0,
      thueTNCN_18: 0,
      thueTNCN_32: 0,
      thueTNCN_52: 0,
      thueTNCN_80: 0,
      thueTNCN_80_: 0,

      sumSalary_CT: 0,

    };
  },

  computed: {
    funcTinhLuong: function() {
      // parse data
      this.SalarySearch = this.SalarySearch.split(',').join('').split('.').join('');
      this.SalaryNgoaiTe = this.SalaryNgoaiTe.split(',').join('').split('.').join('');
      this.SalaryDongBHSearch = this.SalaryDongBHSearch.split(',').join('').split('.').join('');
      this.TiGia = this.TiGia.split(',').join('').split('.').join('');

      // ======================================================== tinh luong ===================================================================

      this.salaryCalculated = this.SalaryNgoaiTe == "" ? this.SalarySearch : parseInt(this.SalaryNgoaiTe) * parseInt(this.TiGia)
      
      this.feeBHXH = this.SalaryDongBHSearch > 29800000 ? 29800000 * this.PERCENT_BHXH_NV : parseInt(this.SalaryDongBHSearch) * this.PERCENT_BHXH_NV
      this.feeBHYT = this.SalaryDongBHSearch > 29800000 ? 29800000 * this.PERCENT_BHYT_NV : parseInt(this.SalaryDongBHSearch) * this.PERCENT_BHYT_NV
      this.feeBHTN = parseInt(this.SalaryDongBHSearch) * this.PERCENT_BHTN_NV

      this.giamTruBT = this.GIAM_BT_NV
      this.giamTruNPT = this.GIAM_NPT_NV * parseInt(this.SoLuongNPT)

      // ==================================================== GROSS sang NET ===================================================================

      if (this.TypeSearch == "GROSS sang NET") {
        this.luongGross = this.salaryCalculated
        
        this.thuNhapTruocThue = parseInt(this.salaryCalculated) - parseInt(this.feeBHXH) - parseInt(this.feeBHYT) - parseInt(this.feeBHTN)
        this.thuNhapChiuThue = parseInt(this.thuNhapTruocThue) - parseInt(this.GIAM_BT_NV) - parseInt(this.GIAM_NPT_NV) * parseInt(this.SoLuongNPT)

        if (this.thuNhapChiuThue > 80000000) {
          this.thueTNCN = parseInt(this.thuNhapChiuThue) * 35 / 100 - 9850000
        } else if (this.thuNhapChiuThue > 52000000) {
          this.thueTNCN = parseInt(this.thuNhapChiuThue) * 30 / 100 - 5850000
        } else if (this.thuNhapChiuThue > 32000000) {
          this.thueTNCN = parseInt(this.thuNhapChiuThue) * 25 / 100 - 3250000
        } else if (this.thuNhapChiuThue > 18000000) {
          this.thueTNCN = parseInt(this.thuNhapChiuThue) * 20 / 100 - 1650000
        } else if (this.thuNhapChiuThue > 10000000) {
          this.thueTNCN = parseInt(this.thuNhapChiuThue) * 15 / 100 - 750000
        } else if (this.thuNhapChiuThue > 5000000) {
          this.thueTNCN = parseInt(this.thuNhapChiuThue) * 10 / 100 - 250000
        } else if (this.thuNhapChiuThue > 0) {
          this.thueTNCN = parseInt(this.thuNhapChiuThue) * 5 / 100
        } else {
          this.thueTNCN = 0
        }

        this.thueTNCN_5 = parseInt(this.thuNhapChiuThue) > 5000000 ? 250000 : parseInt(this.thuNhapChiuThue) * 5 / 100
        this.thueTNCN_10 = parseInt(this.thuNhapChiuThue) > 10000000 ? 750000 : (parseInt(this.thuNhapChiuThue) - 5000000) * 10 / 100
        this.thueTNCN_18 = parseInt(this.thuNhapChiuThue) > 18000000 ? 1650000 : (parseInt(this.thuNhapChiuThue) - 10000000) * 15 / 100
        this.thueTNCN_32 = parseInt(this.thuNhapChiuThue) > 32000000 ? 3250000 : (parseInt(this.thuNhapChiuThue) - 18000000) * 20 / 100
        this.thueTNCN_52 = parseInt(this.thuNhapChiuThue) > 52000000 ? 5850000 : (parseInt(this.thuNhapChiuThue) - 32000000) * 25 / 100
        this.thueTNCN_80 = parseInt(this.thuNhapChiuThue) > 80000000 ? 9850000 : (parseInt(this.thuNhapChiuThue) - 52000000) * 30 / 100
        this.thueTNCN_80_ = parseInt(this.thuNhapChiuThue) <= 80000000 ? -1 : (parseInt(this.thuNhapChiuThue) - 80000000) * 35 / 100 - parseInt(this.thueTNCN_80)

        this.luongNet = parseInt(this.salaryCalculated) - parseInt(this.feeBHXH) - parseInt(this.feeBHYT) - parseInt(this.feeBHTN) - parseInt(this.thueTNCN)
        
      // ============================================================ NET sang GROSS =================================================================

      } else if (this.TypeSearch == "NET sang GROSS") {
        
        this.thuNhapTinhThueNet = this.salaryCalculated == 0 ? 0 : parseInt(this.salaryCalculated) - parseInt(this.GIAM_BT_NV) - parseInt(this.GIAM_NPT_NV) * parseInt(this.SoLuongNPT)
        
        if (this.thuNhapTinhThueNet > 61850000) {
          this.quyDoiSangGross = (this.thuNhapTinhThueNet - 9850000 ) / 0.65
        } else if (this.thuNhapTinhThueNet > 42250000) {
          this.quyDoiSangGross = (this.thuNhapTinhThueNet - 5850000 ) / 0.7
        }  else if (this.thuNhapTinhThueNet > 27250000) {
          this.quyDoiSangGross = (this.thuNhapTinhThueNet - 3250000 ) / 0.75
        }  else if (this.thuNhapTinhThueNet > 16050000) {
          this.quyDoiSangGross = (this.thuNhapTinhThueNet - 1650000 ) / 0.8
        }  else if (this.thuNhapTinhThueNet > 9250000) {
          this.quyDoiSangGross = (this.thuNhapTinhThueNet - 750000 ) / 0.85
        }  else if (this.thuNhapTinhThueNet > 4750000) {
          this.quyDoiSangGross = (this.thuNhapTinhThueNet - 250000 ) / 0.9
        } else {
          this.quyDoiSangGross = (this.thuNhapTinhThueNet) / 0.95
        }

        this.thuNhapChiuThue = this.quyDoiSangGross

        if (this.thuNhapChiuThue > 80000000) {
          this.thueTNCN = parseInt(this.thuNhapChiuThue) * 35 / 100 - 9850000
        } else if (this.thuNhapChiuThue > 52000000) {
          this.thueTNCN = parseInt(this.thuNhapChiuThue) * 30 / 100 - 5850000
        } else if (this.thuNhapChiuThue > 32000000) {
          this.thueTNCN = parseInt(this.thuNhapChiuThue) * 25 / 100 - 3250000
        } else if (this.thuNhapChiuThue > 18000000) {
          this.thueTNCN = parseInt(this.thuNhapChiuThue) * 20 / 100 - 1650000
        } else if (this.thuNhapChiuThue > 10000000) {
          this.thueTNCN = parseInt(this.thuNhapChiuThue) * 15 / 100 - 750000
        } else if (this.thuNhapChiuThue > 5000000) {
          this.thueTNCN = parseInt(this.thuNhapChiuThue) * 10 / 100 - 250000
        } else if (this.thuNhapChiuThue > 0) {
          this.thueTNCN = parseInt(this.thuNhapChiuThue) * 5 / 100
        }
        
        this.thueTNCN_5 = parseInt(this.thuNhapChiuThue) > 5000000 ? 250000 : parseInt(this.thuNhapChiuThue) * 5 / 100
        this.thueTNCN_10 = parseInt(this.thuNhapChiuThue) > 10000000 ? 750000 : (parseInt(this.thuNhapChiuThue) - 5000000) * 10 / 100
        this.thueTNCN_18 = parseInt(this.thuNhapChiuThue) > 18000000 ? 1650000 : (parseInt(this.thuNhapChiuThue) - 10000000) * 15 / 100
        this.thueTNCN_32 = parseInt(this.thuNhapChiuThue) > 32000000 ? 3250000 : (parseInt(this.thuNhapChiuThue) - 18000000) * 20 / 100
        this.thueTNCN_52 = parseInt(this.thuNhapChiuThue) > 52000000 ? 5850000 : (parseInt(this.thuNhapChiuThue) - 32000000) * 25 / 100
        this.thueTNCN_80 = parseInt(this.thuNhapChiuThue) > 80000000 ? 9850000 : (parseInt(this.thuNhapChiuThue) - 52000000) * 30 / 100
        this.thueTNCN_80_ = parseInt(this.thuNhapChiuThue) <= 80000000 ? -1 : (parseInt(this.thuNhapChiuThue) - 80000000) * 35 / 100 - parseInt(this.thueTNCN_80)
        
        this.luongGross = parseInt(this.salaryCalculated) + parseInt(this.feeBHXH) + parseInt(this.feeBHYT) + parseInt(this.feeBHTN) + parseInt(this.thueTNCN)

      }

      this.salaryCalculated = parseInt(this.salaryCalculated)
      this.feeBHXH = parseInt(this.feeBHXH)
      this.feeBHYT = parseInt(this.feeBHYT)
      this.feeBHTN = parseInt(this.feeBHTN)

      this.thuNhapTruocThue = parseInt(this.thuNhapTruocThue)
      this.thuNhapChiuThue = parseInt(this.thuNhapChiuThue)

      this.giamTruBT = parseInt(this.giamTruBT)
      this.giamTruNPT = parseInt(this.giamTruNPT)
      this.thueTNCN = parseInt(this.thueTNCN)

      this.thueTNCN_5 = parseInt(this.thueTNCN_5) < 0 ? "-" : parseInt(this.thueTNCN_5)
      this.thueTNCN_10 = parseInt(this.thueTNCN_10) < 0 ? "-" : parseInt(this.thueTNCN_10)
      this.thueTNCN_18 = parseInt(this.thueTNCN_18) < 0 ? "-" : parseInt(this.thueTNCN_18)
      this.thueTNCN_32 = parseInt(this.thueTNCN_32) < 0 ? "-" : parseInt(this.thueTNCN_32)
      this.thueTNCN_52 = parseInt(this.thueTNCN_52) < 0 ? "-" : parseInt(this.thueTNCN_52)
      this.thueTNCN_80 = parseInt(this.thueTNCN_80) < 0 ? "-" : parseInt(this.thueTNCN_80)
      this.thueTNCN_80_ = parseInt(this.thueTNCN_80_) < 0 ? "-" : parseInt(this.thueTNCN_80_)

      this.luongGross = parseInt(this.luongGross)
      this.luongNet = parseInt(this.luongNet)

      this.thuNhapTinhThueNet = parseInt(this.thuNhapTinhThueNet)
      this.quyDoiSangGross = parseInt(this.quyDoiSangGross)

      // ========================================================= CT trả ==================================================================

      this.feeBHXH_CT = this.SalaryDongBHSearch > 29800000 ? 29800000 * this.PERCENT_BHXH_CT : parseInt(this.SalaryDongBHSearch) * this.PERCENT_BHXH_CT
      this.feeBHYT_CT = this.SalaryDongBHSearch > 29800000 ? 29800000 * this.PERCENT_BHYT_CT : parseInt(this.SalaryDongBHSearch) * this.PERCENT_BHYT_CT
      this.feeBHTN_CT = parseInt(this.SalaryDongBHSearch) * this.PERCENT_BHTN_CT

      this.sumSalary_CT = parseInt(this.luongGross) + parseInt(this.feeBHXH_CT) + parseInt(this.feeBHYT_CT) + parseInt(this.feeBHTN_CT)

      this.feeBHXH_CT = parseInt(this.feeBHXH_CT)
      this.feeBHYT_CT = parseInt(this.feeBHYT_CT)
      this.feeBHTN_CT = parseInt(this.feeBHTN_CT)

      this.sumSalary_CT = parseInt(this.sumSalary_CT)

    }
  }


};
</script>

<style>
  .tab {
    max-height: 580px;
    overflow-y: scroll;
  }
  
  /* scroll bar */
  /* width */
  ::-webkit-scrollbar {
      width: 5px;
      height: 5px;
  }
  /* Track */
  ::-webkit-scrollbar-track {
      background: #fff;
  }
  /* Handle */
  ::-webkit-scrollbar-thumb {
      background: rgba(164, 164, 164, 0.5);
      border-radius: 10px;
  }

  select.gross-or-net:not([size]):not([multiple]) {
    color: #fff;
    background-color: #1999d5;
    background-image: url("https://intertax.vn/wp-content/uploads/2019/07/white-down-arrow-png-2.png") !important;
    font-weight: bold;
    border-radius: 0;
    border: none;
  }

  .table thead th {
    background: rgb(241, 111, 48, 0.75) !important;
    color: #fff !important;
    border: none !important;
  }

  .table-hover tbody tr:hover {
    background: rgb(241, 111, 48, 0.5) !important;
  }

  .form-control:focus {
    border-color: #1999d5;
    box-shadow: inherit
  }

  @media (max-width: 768px) {
    .img-place {
        display: none !important;
    }
  }
</style>
